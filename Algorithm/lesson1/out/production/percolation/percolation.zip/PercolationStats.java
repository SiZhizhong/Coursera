import java.util.Random;

public class PercolationStats {
    private double [] openProb;
    private int n,trials;
    private  double meanProb,stddevNum;

    public PercolationStats(int n, int trials){
        this.openProb=new double[trials];
        this.n=n;
        this.trials=trials;
        int row,col;
        Random ra= new Random();
        Percolation per;
        for(int i=0;i<trials;i++){
            per=new Percolation(n);
            while (!per.percolates()){
                row=ra.nextInt(n);
                col=ra.nextInt(n);
                per.open(row,col);
            }
            this.openProb[i]=(double)per.numberOfOpenSites()/(n*n);
        }



    }
    public double mean(){
        double sum=0;
        for(int i=0;i<this.trials;i++){
            sum+=this.openProb[i];
        }
        this.meanProb=sum/this.trials;
        return this.meanProb;

    }
    public double stddev(){
        double sum=0;
        double mean=this.mean();
        for (int i=0;i<this.trials;i++){
            sum=Math.pow((this.openProb[i]-mean),2);
        }
        this.stddevNum=Math.pow((sum/this.trials),0.5);
        return this.stddevNum;

    }
    public double confidenceLo(){
        return this.meanProb-1.96*this.stddevNum/Math.pow(this.trials,0.5);
    }
    public double confidenceHi(){
        return this.meanProb+1.96*this.stddevNum/Math.pow(this.trials,0.5);
    }

    public static void main(String[]args){
        int n=100;
        int trials=100;
        PercolationStats pers=new PercolationStats(n,trials);
        System.out.println(pers.mean());
        System.out.println(pers.stddev());
    }
}
